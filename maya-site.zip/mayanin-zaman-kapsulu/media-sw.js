// No persistent cache: private media and short-lived authorization remain per tab.
const sessions = new Map();
self.addEventListener('install', () => self.skipWaiting());
self.addEventListener('activate', event => event.waitUntil(self.clients.claim()));
self.addEventListener('message', event => {
  if (!event.source?.id) return;
  const data=event.data;
  if(data?.type==='clear')sessions.delete(event.source.id);
  if(data?.type==='session')sessions.set(event.source.id,{token:data.token,expires:data.expires,files:new Map(data.files)});
  event.ports[0]?.postMessage({ok:true});
});
self.addEventListener('fetch', event => {
  const url=new URL(event.request.url), scope=new URL(self.registration.scope);
  if(url.origin!==scope.origin||!url.pathname.startsWith(scope.pathname+'private-media/'))return;
  event.respondWith((async()=>{
    const session=sessions.get(event.clientId), id=url.pathname.slice((scope.pathname+'private-media/').length), file=session?.files.get(id);
    if(!session||Date.now()>=session.expires||!file)return new Response('Google hesabına yeniden giriş yap.',{status:401});
    const headers=new Headers({Authorization:`Bearer ${session.token}`});
    const range=event.request.headers.get('range');if(range)headers.set('Range',range);
    const upstream=await fetch(`https://www.googleapis.com/drive/v3/files/${encodeURIComponent(file.driveId)}?alt=media`,{headers,credentials:'omit',redirect:'error',cache:'no-store'});
    const output=new Headers({'Content-Type':file.contentType,'Cache-Control':'private, no-store','X-Content-Type-Options':'nosniff','Accept-Ranges':'bytes'});
    for(const name of ['Content-Length','Content-Range']){const value=upstream.headers.get(name);if(value)output.set(name,value);}
    return new Response(upstream.body,{status:upstream.status,headers:output});
  })());
});
